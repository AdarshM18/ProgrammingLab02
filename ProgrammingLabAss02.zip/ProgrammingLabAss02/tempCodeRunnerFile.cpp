  // void display() const {
    //     cout << "Booking for " << customer.getName() << " (" << customer.getEmail() << ")" << endl;
    //     room->display();
    // }