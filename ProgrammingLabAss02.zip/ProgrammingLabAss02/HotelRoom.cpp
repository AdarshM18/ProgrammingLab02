#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Room {
protected:
    int roomNumber;
    string roomType;
    double pricePerNight;
    bool isBooked;

public:
    Room(int num, string type, double price) 
        : roomNumber(num), roomType(type), pricePerNight(price), isBooked(false) {}

    // virtual ~Room() {}

    bool book() {
        if (isBooked) return false;
        isBooked = true;
        return true;
    }

    bool cancel() {
        if (!isBooked) return false;
        isBooked = false;
        return true;
    }

    bool isAvailable() const {
        return !isBooked;
    }

    virtual void display() const {
        cout << "Room " << roomNumber << " (" << roomType << "): " 
             << (isBooked ? "Booked" : "Available") << endl;
    }
};

class SingleRoom : public Room {
public:
    SingleRoom(int num) : Room(num, "Single", 100.0) {}
};

class DoubleRoom : public Room {
public:
    DoubleRoom(int num) : Room(num, "Double", 150.0) {}
};

class SuiteRoom : public Room {
public:
    SuiteRoom(int num) : Room(num, "Suite", 300.0) {}
};

class Customer {
    string name;
    string email;

public:
    Customer(string n, string e) : name(n), email(e) {}

    string getName() const {
        return name;
    }

    string getEmail() const {
        return email;
    }
};

class Booking {
    Customer customer;
    Room* room;

public:
    Booking(Customer c, Room* r) : customer(c), room(r) {}

    const Customer& getCustomer() const {
        return customer;
    }

    Room* getRoom() const {
        return room;
    }

    void display() const {
        cout << "Booking for " << customer.getName() << " (" << customer.getEmail() << ")" << endl;
        room->display();
    }
};

class Hotel {
    vector<Room*> rooms;
    vector<Booking> bookings;

public:
    ~Hotel() {
        for (Room* room : rooms) {
            delete room;
        }
    }

    void addRoom(Room* room) {
        rooms.push_back(room);
    }

    Room* findAvailableRoom() const {
        for (Room* room : rooms) {
            if (room->isAvailable()) {
                return room;
            }
        }
        return nullptr;
    }

    void bookRoom(const Customer& customer) {
        Room* room = findAvailableRoom();
        if (room && room->book()) {
            bookings.push_back(Booking(customer, room));
            cout << "Booking successful!" << endl;
        } else {
            cout << "No available rooms." << endl;
        }
    }

    void cancelBooking(const Customer& customer) {
        for (auto it = bookings.begin(); it != bookings.end(); ++it) {
            if (it->getCustomer().getEmail() == customer.getEmail()) {
                Room* room = it->getRoom();
                if (room->cancel()) {
                    bookings.erase(it);
                    cout << "Booking cancelled successfully!" << endl;
                    return;
                } else {
                    cout << "Failed to cancel booking." << endl;
                }
            }
        }
        cout << "No booking found for this customer." << endl;
    }

    void showRooms() const {
        for (Room* room : rooms) {
            room->display();
        }
    }
    
    void showBookings() const {
        for (const Booking& booking : bookings) {
            booking.display();
        }
    }
};

int main() {
    Hotel hotel;

    hotel.addRoom(new SingleRoom(100));
    hotel.addRoom(new SingleRoom(101));
    hotel.addRoom(new DoubleRoom(102));
    hotel.addRoom(new SuiteRoom(103));

    while (true) {
        cout << "Hotel Booking System" << endl;
        cout << "1. Show available rooms" << endl;
        cout << "2. Book a room" << endl;
        cout << "3. Cancel a booking" << endl;
        cout << "4. Show all bookings" << endl;
        cout << "5. Exit" << endl;
        cout << "Enter your choice: ";

        int choice;
        cin >> choice;
        cin.ignore();

        if (choice == 1) {
            hotel.showRooms();
        } else if (choice == 2) {
            string name, email;
            cout << "Enter customer name: ";
            getline(cin, name);
            cout << "Enter customer email: ";
            getline(cin, email);
            Customer customer(name, email);
            hotel.bookRoom(customer);
        } else if (choice == 3) {
            string email;
            cout << "Enter customer email to cancel booking: ";
            getline(cin, email);
            Customer customer("", email);
            hotel.cancelBooking(customer);
        } else if (choice == 4) {
            hotel.showBookings();
        } else if (choice == 5) {
            break;
        } else {
            cout << "Invalid choice. Please try again." << endl;
        }
    }

    return 0;
}

